package gcit.edu.unit_converter;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class add_data extends AppCompatActivity {
    EditText title_input, author_input;
    Button add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_data);

        title_input = findViewById(R.id.title_input);
        author_input = findViewById(R.id.author_input);
        add_button = findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBmain dBmain = new DBmain(add_data.this);
                dBmain.addBook(title_input.getText().toString().trim(),
                        author_input.getText().toString().trim());
                Intent intent = new Intent(add_data.this, Note.class);
                startActivity(intent);
                finish();
            }
        });
    }



}