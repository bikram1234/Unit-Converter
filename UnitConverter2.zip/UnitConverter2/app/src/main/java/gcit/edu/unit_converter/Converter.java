package gcit.edu.unit_converter;

public class Converter {
    /**
     * Just a way for us to store related constants
     */
    public enum Unit {
        INCH, CENTIMETER, FOOT, YARD, METER, MILE, KILOMETER,
        Microgram, milligram, Gram, Kilogram, Pound, Ton,
        Millisecond, Second, Minute, Hour, Day, Week, Month, Year,
        Meter_Second, Foot_Second, Foot_minute, Kilometer_Minute, Kilometer_hour, Mile_Hour, Meter_Hour, Light_Speed,
        Bit, kilobit, Megabit, Gigabit, Byte, kilobyte, Megabyte, Gigabyte,
        Celcius, Fahrenheit, Kelvin;

        // Helper method to convert text to one of the above constants
        public static Unit fromString(String text) {
            if (text != null) {

                for (Unit unit : Unit.values()) {
                    if (text.equalsIgnoreCase(unit.toString())) {
                        return unit;
                    }
                }
            }

            throw new IllegalArgumentException("Cannot find a value for " + text);
        }
    }

    // What can I multiply by to get me from my fromUnit to my toUnit? double multiplier: get double the amount of points
    private final double multiplier;

    public Converter(Unit from, Unit to) {
        double constant = 1;
        // Set the multiplier, else if fromUnit = toUnit, then it is 1
        switch (from) {
            case INCH:
                if (to == Unit.CENTIMETER) {
                    constant = 2.54;
                } else if (to == Unit.FOOT) {
                    constant = 0.0833333;
                } else if (to == Unit.YARD) {
                    constant = 0.0277778;
                } else if (to == Unit.METER) {
                    constant = 0.0254;
                } else if (to == Unit.MILE) {
                    constant = 1.5783e-5;
                } else if (to == Unit.KILOMETER) {
                    constant = 2.54e-5;
                }
                break;
            case CENTIMETER:
                if (to == Unit.INCH) {
                    constant = 0.393701;
                } else if (to == Unit.FOOT) {
                    constant = 0.0328084;
                } else if (to == Unit.YARD) {
                    constant = 0.0109361;
                } else if (to == Unit.METER) {
                    constant = 0.01;
                } else if (to == Unit.MILE) {
                    constant = 6.2137e-6;
                } else if (to == Unit.KILOMETER) {
                    constant = 1e-5;
                }
                break;
            case FOOT:
                if (to == Unit.INCH) {
                    constant = 12;
                } else if (to == Unit.CENTIMETER) {
                    constant = 30.48;
                } else if (to == Unit.YARD) {
                    constant = 0.333333;
                } else if (to == Unit.METER) {
                    constant = 0.3048;
                } else if (to == Unit.MILE) {
                    constant = 0.000189394;
                } else if (to == Unit.KILOMETER) {
                    constant = 0.0003048;
                }
                break;
            case YARD:
                if (to == Unit.INCH) {
                    constant = 36;
                } else if (to == Unit.CENTIMETER) {
                    constant = 91.44;
                } else if (to == Unit.FOOT) {
                    constant = 3;
                } else if (to == Unit.METER) {
                    constant = 0.9144;
                } else if (to == Unit.MILE) {
                    constant = 0.000568182;
                } else if (to == Unit.KILOMETER) {
                    constant = 0.0009144;
                }
                break;
            case METER:
                if (to == Unit.INCH) {
                    constant = 39.3701;
                } else if (to == Unit.CENTIMETER) {
                    constant = 100;
                } else if (to == Unit.FOOT) {
                    constant = 3.28084;
                } else if (to == Unit.YARD) {
                    constant = 1.09361;
                } else if (to == Unit.MILE) {
                    constant = 0.000621371;
                } else if (to == Unit.KILOMETER) {
                    constant = 0.001;
                }
                break;
            case MILE:
                if (to == Unit.INCH) {
                    constant = 63360;
                } else if (to == Unit.CENTIMETER) {
                    constant = 160934;
                } else if (to == Unit.FOOT) {
                    constant = 5280;
                } else if (to == Unit.YARD) {
                    constant = 1760;
                } else if (to == Unit.METER) {
                    constant = 1609.34;
                } else if (to == Unit.KILOMETER) {
                    constant = 1.60934;
                }
                break;
            case KILOMETER:
                if (to == Unit.INCH) {
                    constant = 39370.1;
                } else if (to == Unit.CENTIMETER) {
                    constant = 100000;
                } else if (to == Unit.FOOT) {
                    constant = 3280.84;
                } else if (to == Unit.YARD) {
                    constant = 1093.61;
                } else if (to == Unit.METER) {
                    constant = 1000;
                } else if (to == Unit.MILE) {
                    constant = 0.621371;
                }
                break;
            case Microgram:
                if (to == Unit.milligram) {
                    constant = 0.001;
                } else if (to == Unit.Gram) {
                    constant = 1e-6;
                } else if (to == Unit.Kilogram) {
                    constant = 1e-9;
                } else if (to == Unit.Pound) {
                    constant = 2.2046e-9;
                } else if (to == Unit.Ton) {
                    constant = 1e-12;
                }
                break;
            case milligram:
                if (to == Unit.Microgram) {
                    constant = 1000;
                } else if (to == Unit.Gram) {
                    constant = 0.001;
                } else if (to == Unit.Kilogram) {
                    constant = 1e-6;
                } else if (to == Unit.Pound) {
                    constant = 2.2046e-6;
                } else if (to == Unit.Ton) {
                    constant = 1e-9;
                }
                break;
            case Gram:
                if (to == Unit.milligram) {
                    constant = 1000;
                } else if (to == Unit.Microgram) {
                    constant = 1e+6;
                } else if (to == Unit.Kilogram) {
                    constant = 0.001;
                } else if (to == Unit.Pound) {
                    constant = 0.00220462;
                } else if (to == Unit.Ton) {
                    constant = 1e-6;
                }
                break;
            case Kilogram:
                if (to == gcit.edu.unit_converter.Converter.Unit.milligram) {
                    constant = 1e+6;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Microgram) {
                    constant = 1e+9;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Gram) {
                    constant = 1000;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Pound) {
                    constant = 2.20462;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Ton) {
                    constant = 0.001;
                }
                break;
            case Pound:
                if (to == gcit.edu.unit_converter.Converter.Unit.milligram) {
                    constant = 453592;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Microgram) {
                    constant = 4.536e+8;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Gram) {
                    constant = 453.592;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Kilogram) {
                    constant = 0.453592;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Ton) {
                    constant = 0.000453592;
                }
                break;
            case Ton:
                if (to == gcit.edu.unit_converter.Converter.Unit.milligram) {
                    constant = 1e+9;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Microgram) {
                    constant = 1e+12;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Gram) {
                    constant = 1e+6;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Kilogram) {
                    constant = 1000;
                } else if (to == gcit.edu.unit_converter.Converter.Unit.Pound) {
                    constant = 2204.62;
                }
                break;
            case Millisecond:
                if (to == Unit.Second) {
                    constant = 0.001;
                } else if (to == Unit.Minute) {
                    constant = 1.6667e-5;
                } else if (to == Unit.Hour) {
                    constant = 2.7778e-7;
                } else if (to == Unit.Day) {
                    constant = 1.1574e-8;
                } else if (to == Unit.Week) {
                    constant = 1.6534e-9;
                } else if (to == Unit.Month) {
                    constant = 3.8052e-10;
                }else if (to == Unit.Year) {
                    constant = 3.171e-11;
                }
                break;
            case Second:
                if (to == Unit.Millisecond) {
                    constant = 1000;
                } else if (to == Unit.Minute) {
                    constant = 0.0166667;
                } else if (to == Unit.Hour) {
                    constant = 0.000277778;
                } else if (to == Unit.Day) {
                    constant = 1.1574e-5;
                } else if (to == Unit.Week) {
                    constant = 1.6534e-6;
                } else if (to == Unit.Month) {
                    constant = 3.8052e-7;
                }else if (to == Unit.Year) {
                    constant = 3.171e-8;
                }
                break;
            case Minute:
                if (to == Unit.Millisecond) {
                    constant = 60000;
                } else if (to == Unit.Second) {
                    constant = 60;
                } else if (to == Unit.Hour) {
                    constant = 0.0166667;
                } else if (to == Unit.Day) {
                    constant = 0.000694444;
                } else if (to == Unit.Week) {
                    constant = 9.9206e-5;
                } else if (to == Unit.Month) {
                    constant = 2.2831e-5;
                }else if (to == Unit.Year) {
                    constant = 1.9026e-6;
                }
                break;
            case Hour:
                if (to == Unit.Millisecond) {
                    constant = 3.6e+6;
                } else if (to == Unit.Second) {
                    constant = 3600;
                } else if (to == Unit.Minute) {
                    constant = 60;
                } else if (to == Unit.Day) {
                    constant = 0.0416667;
                } else if (to == Unit.Week) {
                    constant = 0.00595238;
                } else if (to == Unit.Month) {
                    constant = 0.00136986;
                }else if (to == Unit.Year) {
                    constant = 0.000114155;
                }
                break;
            case Day:
                if (to == Unit.Millisecond) {
                    constant = 8.64e+7;
                } else if (to == Unit.Second) {
                    constant = 86400;
                } else if (to == Unit.Minute) {
                    constant = 1440;
                } else if (to == Unit.Hour) {
                    constant = 24;
                } else if (to == Unit.Week) {
                    constant = 0.142857;
                } else if (to == Unit.Month) {
                    constant = 0.0328767;
                }else if (to == Unit.Year) {
                    constant = 0.00273973;
                }
                break;
            case Week:
                if (to == Unit.Millisecond) {
                    constant = 6.048e+8;
                } else if (to == Unit.Second) {
                    constant = 604800;
                } else if (to == Unit.Minute) {
                    constant = 10080;
                } else if (to == Unit.Hour) {
                    constant = 168;
                } else if (to == Unit.Day) {
                    constant = 7;
                } else if (to == Unit.Month) {
                    constant = 0.230137;
                }else if (to == Unit.Year) {
                    constant = 0.0191781;
                }
                break;
            case Month:
                if (to == Unit.Millisecond) {
                    constant = 2.628e+9;
                } else if (to == Unit.Second) {
                    constant = 2.628e+6;
                } else if (to == Unit.Minute) {
                    constant = 43800;
                } else if (to == Unit.Hour) {
                    constant = 730.001;
                } else if (to == Unit.Day) {
                    constant = 30.4167;
                } else if (to == Unit.Week) {
                    constant = 4.34524;
                }else if (to == Unit.Year) {
                    constant = 0.0833334;
                }
                break;
            case Year:
                if (to == Unit.Millisecond) {
                    constant = 3.154e+10;
                } else if (to == Unit.Second) {
                    constant = 3.154e+7;
                } else if (to == Unit.Minute) {
                    constant = 525600;
                } else if (to == Unit.Hour) {
                    constant = 8760;
                } else if (to == Unit.Day) {
                    constant = 365;
                } else if (to == Unit.Week) {
                    constant = 52.1429;
                }else if (to == Unit.Month) {
                    constant = 12;
                }
                break;
            case Meter_Second:
                if (to == Unit.Foot_Second) {
                    constant = 3.2808399;
                } else if (to == Unit.Foot_minute) {
                    constant = 196.85;
                } else if (to == Unit.Kilometer_Minute) {
                    constant = 0.06;
                } else if (to == Unit.Kilometer_hour) {
                    constant = 3.6;
                } else if (to == Unit.Mile_Hour) {
                    constant = 2.23694;
                } else if (to == Unit.Meter_Hour) {
                    constant = 3600;
                }else if (to == Unit.Light_Speed) {
                    constant = 3.33564e-9;
                }
                break;
            case Foot_Second:
                if (to == Unit.Meter_Second) {
                    constant = 0.3048;
                } else if (to == Unit.Foot_minute) {
                    constant = 60;
                } else if (to == Unit.Kilometer_Minute) {
                    constant = 0.018288;
                } else if (to == Unit.Kilometer_hour) {
                    constant = 1.09728;
                } else if (to == Unit.Mile_Hour) {
                    constant = 0.681818;
                } else if (to == Unit.Meter_Hour) {
                    constant = 1097.28;
                }else if (to == Unit.Light_Speed) {
                    constant = 1.0167e-9;
                }
                break;
            case Foot_minute:
                if (to == Unit.Meter_Second) {
                    constant = 0.00508;
                } else if (to == Unit.Foot_Second) {
                    constant = 0.0166667;
                } else if (to == Unit.Kilometer_Minute) {
                    constant = 0.0003048;
                } else if (to == Unit.Kilometer_hour) {
                    constant = 0.018288;
                } else if (to == Unit.Mile_Hour) {
                    constant = 0.0113636;
                } else if (to == Unit.Meter_Hour) {
                    constant = 18.288;
                }else if (to == Unit.Light_Speed) {
                    constant = 1.6945e-11;
                }
                break;
            case Kilometer_Minute:
                if (to == Unit.Meter_Second) {
                    constant = 16.6667;
                } else if (to == Unit.Foot_Second) {
                    constant = 54.6807;
                } else if (to == Unit.Foot_minute) {
                    constant = 3280.84;
                } else if (to == Unit.Kilometer_hour) {
                    constant = 60;
                } else if (to == Unit.Mile_Hour) {
                    constant = 37.2823;
                } else if (to == Unit.Meter_Hour) {
                    constant = 60000;
                }else if (to == Unit.Light_Speed) {
                    constant = 5.5594e-8;
                }
                break;
            case Kilometer_hour:
                if (to == Unit.Meter_Second) {
                    constant = 0.277778;
                } else if (to == Unit.Foot_Second) {
                    constant = 0.911344;
                } else if (to == Unit.Foot_minute) {
                    constant = 54.6807;
                } else if (to == Unit.Kilometer_Minute) {
                    constant = 0.0166667;
                } else if (to == Unit.Mile_Hour) {
                    constant = 0.621371;
                } else if (to == Unit.Meter_Hour) {
                    constant = 999.999;
                }else if (to == Unit.Light_Speed) {
                    constant = 9.26567e-10;
                }
                break;
            case Mile_Hour:
                if (to == Unit.Meter_Second) {
                    constant = 0.44704;
                } else if (to == Unit.Foot_Second) {
                    constant = 1.46667;
                } else if (to == Unit.Foot_minute) {
                    constant = 88;
                } else if (to == Unit.Kilometer_Minute) {
                    constant = 0.0268224;
                } else if (to == Unit.Kilometer_hour) {
                    constant = 1.60934;
                } else if (to == Unit.Meter_Hour) {
                    constant = 1609.34;
                }else if (to == Unit.Light_Speed) {
                    constant = 1.49116e-9;
                }
                break;
            case Meter_Hour:
                if (to == Unit.Meter_Second) {
                    constant = 0.000277778;
                } else if (to == Unit.Foot_Second) {
                    constant = 0.000911345;
                } else if (to == Unit.Foot_minute) {
                    constant = 0.0546807;
                } else if (to == Unit.Kilometer_Minute) {
                    constant = 1.6667e-5;
                } else if (to == Unit.Kilometer_hour) {
                    constant = 0.001;
                } else if (to == Unit.Mile_Hour) {
                    constant = 0.000621372;
                }else if (to == Unit.Light_Speed) {
                    constant = 9.26567e-13;
                }
                break;
            case Light_Speed:
                if (to == Unit.Meter_Second) {
                    constant = 2.998e+8;
                } else if (to == Unit.Foot_Second) {
                    constant = 9.836e+8;
                } else if (to == Unit.Foot_minute) {
                    constant = 5.901e+10;
                } else if (to == Unit.Kilometer_Minute) {
                    constant = 1.799e+7;
                } else if (to == Unit.Kilometer_hour) {
                    constant = 1.079e+9;
                } else if (to == Unit.Mile_Hour) {
                    constant = 6.706e+8;
                }else if (to == Unit.Meter_Hour) {
                    constant = 1.079e+12;
                }
                break;
            case Bit:
                if (to == Unit.kilobit) {
                    constant = 0.001;
                } else if (to == Unit.Megabit) {
                    constant = 1e-6;
                } else if (to == Unit.Gigabit) {
                    constant = 1e-9;
                } else if (to == Unit.Byte) {
                    constant = 0.125;
                } else if (to == Unit.kilobyte) {
                    constant = 0.000125;
                } else if (to == Unit.Megabyte) {
                    constant = 0.000000125;
                }else if (to == Unit.Gigabyte) {
                    constant = 0.000000000125;
                }
                break;
            case kilobit:
                if (to == Unit.Bit) {
                    constant = 1000;
                } else if (to == Unit.Megabit) {
                    constant = 0.001;
                } else if (to == Unit.Gigabit) {
                    constant = 0.000001;
                } else if (to == Unit.Byte) {
                    constant = 125;
                } else if (to == Unit.kilobyte) {
                    constant = 0.125;
                } else if (to == Unit.Megabyte) {
                    constant = 0.000125;
                }else if (to == Unit.Gigabyte) {
                    constant = 0.000000125;
                }
                break;
            case Megabit:
                if (to == Unit.Bit) {
                    constant = 1000000;
                } else if (to == Unit.kilobit) {
                    constant = 1000;
                } else if (to == Unit.Gigabit) {
                    constant = 0.001;
                } else if (to == Unit.Byte) {
                    constant = 125000;
                } else if (to == Unit.kilobyte) {
                    constant = 125;
                } else if (to == Unit.Megabyte) {
                    constant = 0.125;
                }else if (to == Unit.Gigabyte) {
                    constant = 0.000125;
                }
                break;
            case Gigabit:
                if (to == Unit.Bit) {
                    constant = 1e+9;
                } else if (to == Unit.kilobit) {
                    constant = 1000000;
                } else if (to == Unit.Megabit) {
                    constant = 1000;
                } else if (to == Unit.Byte) {
                    constant = 1.25e+8;
                } else if (to == Unit.kilobyte) {
                    constant = 125000;
                } else if (to == Unit.Megabyte) {
                    constant = 125;
                }else if (to == Unit.Gigabyte) {
                    constant = 0.125;
                }
                break;
            case Byte:
                if (to == Unit.Bit) {
                    constant = 8;
                } else if (to == Unit.kilobit) {
                    constant = 0.008;
                } else if (to == Unit.Megabit) {
                    constant = 0.000008;
                } else if (to == Unit.Gigabit) {
                    constant = 8e-9;
                } else if (to == Unit.kilobyte) {
                    constant = 0.001;
                } else if (to == Unit.Megabyte) {
                    constant = 0.000001;
                }else if (to == Unit.Gigabyte) {
                    constant = 1e-9;
                }
                break;
            case kilobyte:
                if (to == Unit.Bit) {
                    constant = 8000;
                } else if (to == Unit.kilobit) {
                    constant = 8;
                } else if (to == Unit.Megabit) {
                    constant = 0.008;
                } else if (to == Unit.Gigabit) {
                    constant = 0.000008;
                } else if (to == Unit.Byte) {
                    constant = 1000;
                } else if (to == Unit.Megabyte) {
                    constant = 0.001;
                }else if (to == Unit.Gigabyte) {
                    constant = 0.000001;
                }
                break;
            case Megabyte:
                if (to == Unit.Bit) {
                    constant = 8000000;
                } else if (to == Unit.kilobit) {
                    constant = 8000;
                } else if (to == Unit.Megabit) {
                    constant = 8;
                } else if (to == Unit.Gigabit) {
                    constant = 0.008;
                } else if (to == Unit.Byte) {
                    constant = 1000000;
                } else if (to == Unit.kilobyte) {
                    constant = 1000;
                }else if (to == Unit.Gigabyte) {
                    constant = 0.001;
                }
                break;
            case Gigabyte:
                if (to == Unit.Bit) {
                    constant = 8e+9;
                } else if (to == Unit.kilobit) {
                    constant = 8000000;
                } else if (to == Unit.Megabit) {
                    constant = 8000;
                } else if (to == Unit.Gigabit) {
                    constant = 8;
                } else if (to == Unit.Byte) {
                    constant = 1e+9;
                } else if (to == Unit.kilobyte) {
                    constant = 1000000;
                }else if (to == Unit.Megabyte) {
                    constant = 1000;
                }
                break;
            case Celcius:
                if (to == Unit.Fahrenheit) {
                    constant = 33.8;
                }else if (to == Unit.Kelvin) {
                    constant = 274.15;
                }
                break;
            case Fahrenheit:
                if (to == Unit.Celcius) {
                    constant = -17.2222;
                } else if (to == Unit.Kelvin) {
                    constant = 255.928;
                }
                break;
            case Kelvin:
                if (to == Unit.Celcius) {
                    constant = -272.15;
                } else if (to == Unit.Fahrenheit) {
                    constant = -457.87;
                }
                break;
        }

        multiplier = constant;
    }

    // Convert the unit!
    public double convert(double input) {
        return input * multiplier;
    }

}

