package gcit.edu.unit_converter;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    Toolbar toolbar;
    DrawerLayout drawerLayout;
    NavigationView navigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.main_toolbar);

        drawerLayout = findViewById(R.id.drawer_layout);

        navigationView = findViewById(R.id.nav_view);


        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                toolbar,
                R.string.opennavDrawer,
                R.string.closenavDrawer
        );

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()){
                case R.id.nav_Distance:
                    startActivity(new Intent(this,Distance.class));
                    break;
                case R.id.nav_Digital:
                    startActivity(new Intent(this,Digital_Storage.class));
                    break;
                case R.id.nav_temp:
                    startActivity(new Intent(this,Temperature.class));
                    break;
                case R.id.nav_speed:
                    startActivity(new Intent(this,Speed.class));
                    break;
                case R.id.nav_time:
                    startActivity(new Intent(this,Time.class));
                    break;
                case R.id.nav_weight:
                    startActivity(new Intent(this,Weight.class));
                    break;
                case R.id.nav_his:
                    startActivity(new Intent(this,Note.class));
            }
            return false;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
    public void dis(View view) {
        Intent obj = new Intent(this, Distance.class);
        startActivity(obj);
    }

    public void weight(View view) {
        Intent obj = new Intent(this, Weight.class);
        startActivity(obj);
    }

    public void temp(View view) {
        Intent obj = new Intent(this, Temperature.class);
        startActivity(obj);
    }

    public void time(View view) {
        Intent obj = new Intent(this, Time.class);
        startActivity(obj);
    }

    public void speed(View view) {
        Intent intent = new Intent(this, Speed.class);
        startActivity(intent);
    }

    public void digital(View view) {
        Intent intent = new Intent(this, Digital_Storage.class);
        startActivity(intent);
    }
}